# accenture
 
This project was for Techtorium, for a fake company called First Class Interiors.

It's purpose is to allow this fake company to run their business from the web

Credits:
Cassidy Brookland
Dylan Prins
James Waddell
Brendon Theorn
